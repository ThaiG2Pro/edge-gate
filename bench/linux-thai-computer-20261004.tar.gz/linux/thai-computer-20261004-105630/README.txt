Đo trên thai-computer, 2026-10-04T11:47:08+07:00, kernel 7.2.8-1-cachyos, 16 core.
Mỗi .txt là 3 lần của một phép đo — lấy MEDIAN, bỏ lần đầu nếu lệch (JIT/cache).
So TỈ SỐ với số WSL2 trong bench/*.txt; số tuyệt đối giữa hai máy không so trực tiếp.
Đọc tiêu chí từng nợ trong docs/REPRODUCE-LINUX.md.
